#!/usr/bin/env python

#--------------------------------------------------------
# The classes for Wire Scanner Accelerator Node
#--------------------------------------------------------

import math
import sys
import os
import random
import time

from orbit.core.spacecharge import Grid1D
from orbit.core.orbit_utils import Function

from orbit.core.orbit_utils import BunchExtremaCalculator

from orbit.py_linac.lattice import BaseLinacNode

class WS_AccNode(BaseLinacNode):
	"""
	Generates the Histograms for distribution in x,y, and z directions.
	"""
	def __init__(self,name = "WS", n_x_points = 50, n_y_points = 50, n_z_points = 50):
		BaseLinacNode.__init__(self,name)
		self.bunch_extrema_calculator = BunchExtremaCalculator()
		self.n_x_points = 50
		self.n_y_points = 50
		self.n_z_points = 50
		self.grid1d_x = Grid1D(self.n_x_points)
		self.grid1d_y = Grid1D(self.n_y_points)
		self.grid1d_z = Grid1D(self.n_z_points)
		#---- rms values for x,y,z directions in [mm]
		self.rms_arr = [0.,0.,0.]

	def setHistSizes(self, n_x_points = 50, n_y_points = 50, n_z_points = 50):
		"""
		Changes the grid (x,y,z)sizes.
		"""
		self.n_x_points = n_x_points
		self.n_y_points = n_y_points
		self.n_z_points = n_z_points
		self.updateGridSizes()
		
	def getHistSizes(self):
		"""
		Returns grid sizes (x,y,z) tuple.
		"""
		return (self.n_x_points, self.n_y_points, self.n_z_points)
		
	def updateGridSizes(self):
		"""
		Creates new grid1d objects.
		"""
		self.grid1d_x = Grid1D(self.n_x_points)
		self.grid1d_y = Grid1D(self.n_y_points)
		self.grid1d_z = Grid1D(self.n_z_points)
		
	def track(self, paramsDict):
		"""
		The WS_AccNode class implementation of the AccNode class track(parameters_dict) method.
		Remember that (xMin,xMax,yMin,yMax,zMin,zMax) are all in meters.
		"""
		bunch = paramsDict["bunch"]
		(xMin,xMax,yMin,yMax,zMin,zMax) = self.bunch_extrema_calculator.extremaXYZ(bunch)		
		self.grid1d_x.setGridZ(xMin,xMax)
		self.grid1d_y.setGridZ(yMin,yMax)
		self.grid1d_z.setGridZ(zMin,zMax)
		self.grid1d_x.setZero()
		self.grid1d_y.setZero()
		self.grid1d_z.setZero()
		if(bunch.getSize() == 0): return
		#---- bin macro-particles into the grids ----------------
		macroSize_init = bunch.macroSize()
		#---- we want to be sure that we have non-zero macro size
		bunch.macroSize(1.0)
		self.grid1d_x.binBunch(bunch,0)
		self.grid1d_y.binBunch(bunch,2)
		self.grid1d_z.binBunch(bunch,4)
		bunch.macroSize(macroSize_init)
		#---- calculate RMSs
		self.analyze()
		
	def analyze(self):
		"""
		Normalizes the distribution in grids and calculates RMS.
		"""
		grid_arr = [self.grid1d_x,self.grid1d_y,self.grid1d_z]
		self.rms_arr = [0.,0.,0.]
		for grid_ind , grid in  enumerate(grid_arr):
			step = grid.getStepZ()
			sum_grid_values = grid.getSum()
			integral = sum_grid_values*step
			if(abs(integral) > 0.):
				grid.multiply(1./integral)
			x_avg = 0.
			x2_avg = 0.
			sum_grid_values = grid.getSum()
			for ind in range(grid.getSizeZ()):
				x = grid.getGridZ(ind)
				val = grid.getValueOnGrid(ind)
				x_avg += x*val
				x2_avg += x**2*val
			if(sum_grid_values != 0.):
				x_avg /= sum_grid_values 
				x2_avg /= sum_grid_values
			#---- rms values will be in mm instead of meters
			rms = 1000.*math.sqrt(abs(x2_avg - x_avg**2))
			self.rms_arr[grid_ind] = rms
		return self.rms_arr
		
		
	def writeToASCII(self, prefix = "", suffix = ""):
		"""
		Wrire WS wave-forms into the files with the names of the WS.
		"""
		name_x = prefix+self.getName().replace(":","_")+"_x"+suffix+".dat"
		name_y = prefix+self.getName().replace(":","_")+"_y"+suffix+".dat"
		name_z = prefix+self.getName().replace(":","_")+"_z"+suffix+".dat"
		name_arr = [name_x,name_y,name_z]
		grid_arr = [self.grid1d_x,self.grid1d_y,self.grid1d_z]
		for grid_ind , grid in  enumerate(grid_arr):
			name = name_arr[grid_ind]
			fl_out = open(name,"w")
			for ind in range(grid.getSizeZ()):
				#---- x in meters
				x = grid.getGridZ(ind)
				val = grid.getValueOnGrid(ind)
				s = " %3d %12.5g %12.5g "%(ind,x*1000.,val)
				fl_out.write(s+"\n")
			fl_out.close()
		
	def getRMSs(self):
		""" 
		returns rms for x,y,z distribution. Values are in mm
		"""
		return self.rms_arr
