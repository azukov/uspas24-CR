#! /usr/bin/env python3

"""
   Set of classes for harmonic analysis of the bpm phases in the cavity's 
   phase scan.
"""

import os
import sys
import math
import random
import time

from orbit.utils  import phaseNearTargetPhaseDeg
from orbit.core.orbit_utils import Function
from orbit.core.orbit_utils import HarmonicData

from orbit.utils.fitting import Solver
from orbit.utils.fitting import Scorer
from orbit.utils.fitting import SolveStopperFactory
from orbit.utils.fitting import ScoreboardActionListener
from orbit.utils.fitting import VariableProxy
from orbit.utils.fitting import TrialPoint

from orbit.utils.fitting import SimplexSearchAlgorithm

def fitCosineFunc(x_arr,y_arr, show_progress = False):
	"""
	This method fit cosine function parameters to the BPM phase scan.
	It is fast. The results will be used to guess the cavity parameters for
	the following fitting.
	"""
	#---- Search algorithm from PyORBIT native package
	searchAlgorithm = SimplexSearchAlgorithm()

	#maxIter = 100
	#solverStopper = SolveStopperFactory.maxIterationStopper(maxIter)
	max_time = 0.05
	solverStopper = SolveStopperFactory.maxTimeStopper(max_time)

	solver = Solver()
	solver.setAlgorithm(searchAlgorithm)
	solver.setStopper(solverStopper)
	
	scorer = CosFittingScorer(x_arr,y_arr)
	trialPoint = scorer.getInitialTrialPoint()
	#---- debug printing of the initial data and fitted values
	#scorer.printDataAndFit(trialPoint)

	class BestScoreListener(ScoreboardActionListener):
		def __init__(self):
			ScoreboardActionListener.__init__(self)
			
		def performAction(self,solver):
			scoreBoard = solver.getScoreboard()
			iteration = scoreBoard.getIteration()
			trialPoint = scoreBoard.getBestTrialPoint()
			print ("============= iter=",scoreBoard.getIteration()," best score=",scoreBoard.getBestScore())
			print (trialPoint.textDesciption())
	
	#---- if we want to see the progress of fitting
	if(show_progress == True):
		solver.getScoreboard().addBestScoreListener(BestScoreListener())
	solver.solve(scorer,trialPoint)	

	#---- the fitting process ended, now we see results
	#print ("===== best score ========== fitting time =",solver.getScoreboard().getRunTime())
	#bestScore = solver.getScoreboard().getBestScore()	
	#print ("best score=",bestScore," iteration=",solver.getScoreboard().getIteration())
	trialPoint = solver.getScoreboard().getBestTrialPoint()
	#print (trialPoint.textDesciption())
	
	#---- getting A0+A1*cos(phase+offset1)
	[avg_val,amp,phase_offset] = trialPoint.getVariableProxyValuesArr()
	#---- debug printing of the initial data and fitted values
	#scorer.printDataAndFit(trialPoint)
	return ((amp,phase_offset,avg_val),scorer)
		
def getCosineParamsEstimation(x_arr,y_arr):
	"""
	It returns estimation for phase offset and amplitude for A*cos(phase - 180. + offset) + avg_val.
	because BPM phase minimum is a maximal acceleration.
	"""
	if(len(x_arr) < 8 or len(x_arr) != len(y_arr)): return (0.,0.,0.)
	y_max = max(y_arr)
	y_min = min(y_arr)
	y_max_ind = y_arr.index(y_max)
	y_min_ind = y_arr.index(y_min)
	#---- estimations
	amp = (y_max - y_min)/2.
	phase_offset = - phaseNearTargetPhaseDeg(x_arr[y_max_ind],0.)
	avg_val = sum(y_arr)/len(y_arr)
	return (phase_offset,amp,avg_val)
	
class CosFittingScorer(Scorer):
	"""
	The Scorer implementation for A0+A1*cos(phase + offset1)
	"""
	def __init__(self,x_arr,y_arr):
		if(len(x_arr) != len(y_arr) or len(x_arr) < 8):
			print ("CosFittingScorer class constructor.")
			print ("Problem with bpm_phase(cav_phase) data.")
			print ("You should have more than 8 points.")
			print ("x_arr=",x_arr)
			print ("y_arr=",y_arr)
			print ("Stop.")
			sys.exit(1)
		#------------------------
		self.x_arr = x_arr
		self.y_arr = y_arr
		(phase_offset,amp,avg_val) = getCosineParamsEstimation(self.x_arr,self.y_arr)
		#---- let's make harmonic data
		f = Function()
		for ind in range(len(x_arr)):
			f.add(self.x_arr[ind],y_arr[ind],0.)
		#---- harmonic data for order = 1 means A0+A1*cos(phase + offset1)
		order = 1
		self.harmonic_data = HarmonicData(order,f)
		self.amp = amp
		self.phase_offset = phase_offset
		self.avg_val = avg_val
		self.amp_relative_step = 0.1
		self.phase_abs_step = 5.0

	def getInitialTrialPoint(self):
		variableProxy_arr = []
		var = VariableProxy("avg_val", self.avg_val , self.phase_abs_step)
		variableProxy_arr.append(var)		
		var = VariableProxy("A", self.amp , self.amp_relative_step*self.amp)
		variableProxy_arr.append(var)
		var = VariableProxy("phase_offset", self.phase_offset , self.phase_abs_step)
		variableProxy_arr.append(var)
		#-----------------------------------
		trialPoint = TrialPoint()
		for variableProxy in variableProxy_arr:
			trialPoint.addVariableProxy(variableProxy)
		return trialPoint

	def updateParameters(self,trialPoint):
		"""
		Put parameters from trialPoint to avg_val,amp,phase_offset
		"""
		param_arr = trialPoint.getVariableProxyValuesArr()
		self.avg_val = param_arr[0]
		self.amp = param_arr[1]
		self.phase_offset = param_arr[2]

	def getScore(self,trialPoint):
		"""
		Implementation of getScore method for Scorer class.
		Calculates sum of squares of differences between initial fitted values
		"""
		param_arr = trialPoint.getVariableProxyValuesArr()
		for param_ind in range(3):
			self.harmonic_data.parameter(param_ind,param_arr[param_ind])
		self.updateParameters(trialPoint)
		return self.harmonic_data.sumDiff2()
		
	def getFittedArrays(self,trialPoint = None):
		"""
		Returns fitted results lists and (y-y_fit) deviation list 
		"""
		x_fit_arr = []
		y_fit_arr = []
		y_err_arr = []
		if(trialPoint == None):
			trialPoint = self.getInitialTrialPoint()
		score = self.getScore(trialPoint)
		for ind in range(self.harmonic_data.dataSize()):
			x = self.harmonic_data.valueX(ind)
			y = self.harmonic_data.valueY(ind)
			y_fit = self.harmonic_data.fitValueY(x)
			x_fit_arr.append(x)
			y_fit_arr.append(y_fit)
			y_err_arr.append(y-y_fit)
		return (x_fit_arr,y_fit_arr,y_err_arr)

	def printDataAndFit(self,trialPoint = None):
		"""
		Method for debugging the fitting process.
		"""
		if(trialPoint == None):
			trialPoint = self.getInitialTrialPoint()
		#----- this will set the trial point to the harmonic_data
		score = self.getScore(trialPoint)
		print (trialPoint.textDesciption())
		print ("======= Harmonic Analysis Data vs. Fit ================")
		print ("Score = ",math.sqrt(score))
		for ind in range(self.harmonic_data.dataSize()):
			x = self.harmonic_data.valueX(ind)
			y = self.harmonic_data.valueY(ind)
			y_err = self.harmonic_data.valueErr(ind)
			y_fit = self.harmonic_data.fitValueY(x)
			print ("ind= %3d "%ind, " (x,y+-y_err,y_fit) = ( %8.1f , %+8.5f +- %8.5f ,%8.5f)"%(x,y,y_err,y_fit))
