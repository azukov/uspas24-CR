#!/usr/bin/env python

#--------------------------------------------------------
# The classes for BPM Model Accelerator Node
#--------------------------------------------------------

import math
import sys
import os
import random
import time

from orbit.lattice import AccNode

from orbit.py_linac.lattice import BaseLinacNode

from orbit.utils import phaseNearTargetPhaseDeg

from orbit.core.bunch import BunchTwissAnalysis
#---- instance of a class for Bunch analysis
twiss_analysis = BunchTwissAnalysis()

class ModelBPM(BaseLinacNode):
	"""
	BPM node for beam coordinates, phase, and amplitude reporting.
	position - in meters
	peak_current - in mA
	bpm_frequency - in Hz
	"""
	def __init__(self, twiss_analysis, bpm, position, peak_current_init = 38.0, bpm_frequency = 402.5e+6):
		name = bpm.getName()+"-model"
		BaseLinacNode.__init__(self,name)
		self.setParam("pos",position)
		#---- bpm is a usual linac lattice marker
		self.bpm = bpm
		#---- bpm_frequency MHz
		self.bpm_frequency = bpm_frequency
		self.twiss_analysis = twiss_analysis
		#---- will be in mm and mrad
		self.x = 0.
		self.y = 0.
		self.xp = 0.
		self.yp = 0.
		#---- will be in deg
		self.avg_phase = 0.
		self.synch_phase = 0.
		#---- will be in MeV
		self.eKin = 0.
		#---- BPM amplitude
		self.bpm_amp = 0.
		self.z_rms_deg = 0.
		#---- arrival time 
		self.bpm_time = 0.
		#--- speed of light
		self.v_light = 2.99792458e+8  # in [m/sec]
		self.bpm_wave_lenght = self.v_light/self.bpm_frequency
		#---- initial number of particles
		self.nParticles = 0
		self.peak_current_init = peak_current_init
		self.peak_current = 0.

	def getBPM(self):
		"""
		Return BaseLinacNode Marker which is a node in the lattice and a parent
		for ths bpm_model node.
		"""
		return self.bpm
		
	def setNumberParticles(self,nParticles):
		"""
		Sets the initial number of particles at the lattice start.
		"""
		self.nParticles = nParticles
	
	def trackDesign(self, paramsDict):
		"""
		The synch. particle values will be used 
		"""
		bunch = paramsDict["bunch"]
		self.x = 0.
		self.y = 0.
		self.xp = 0.
		self.yp = 0.
		self.bpm_amp = 0.
		self.z_rms_deg = 0.
		#---- phase shift for the bunch as whole
		self.delta_phase = 0.
		#---- phase will be in deg
		self.bpm_time = bunch.getSyncParticle().time()
		self.avg_phase = phaseNearTargetPhaseDeg(self.bpm_time*360.0*self.bpm_frequency,0.)
		#---- will be in MeV
		self.eKin = bunch.getSyncParticle().kinEnergy()*1.0e+3

	def track(self, paramsDict):
		"""
		It is tracking the bunch through this node.
		"""
		bunch = paramsDict["bunch"]
		nParts = bunch.getSize()
		self.peak_current = 0.
		if(nParts < 3):
			self.x = 0.
			self.y = 0.
			self.xp = 0.
			self.yp = 0.
			self.avg_phase = 0.
			self.eKin = 0.
			return
		self.twiss_analysis.analyzeBunch(bunch)
		self.x = self.twiss_analysis.getAverage(0)*1000.
		self.y = self.twiss_analysis.getAverage(2)*1000.
		self.xp = self.twiss_analysis.getAverage(1)*1000.
		self.yp = self.twiss_analysis.getAverage(3)*1000.
		#------------------------------------------------------------------------
		#---- calcilation of BPM amplitude as exp(-2*pi^2*(sigma_z_deg/360)^2)
		z_rms = math.sqrt(self.twiss_analysis.getTwiss(2)[1]*self.twiss_analysis.getTwiss(2)[3])
		bunch_lambda = bunch.getSyncParticle().beta()*self.bpm_wave_lenght 
		self.z_rms_deg = z_rms*360./bunch_lambda
		#---- peak current
		self.peak_current = self.peak_current_init*(1.0*nParts)/self.nParticles
		self.bpm_amp = self.peak_current*math.exp(-2.0*(math.pi*(self.z_rms_deg/360.))**2)
		#print "debug ============== self.bpm_amp = ",self.bpm_amp)
		#-------------------------------------------------------------------------
		#---- calculation of time center of mass bunch shift from synch. particle
		z_avg  = self.twiss_analysis.getAverage(4)
		beta = bunch.getSyncParticle().beta()
		self.bpm_time = bunch.getSyncParticle().time()
		delta_time_avg = z_avg/(beta*self.v_light)
		self.delta_phase = -360.0*self.bpm_frequency*delta_time_avg		
		bpm_time_shifted = self.bpm_time - delta_time_avg
		self.avg_phase = phaseNearTargetPhaseDeg(bpm_time_shifted*360.0*self.bpm_frequency,0.)
		self.synch_phase = phaseNearTargetPhaseDeg(self.bpm_time*360.0*self.bpm_frequency,0.)
		#---------------------------------------------------
		dE_avg = self.twiss_analysis.getAverage(5)
		self.eKin = (bunch.getSyncParticle().kinEnergy() + dE_avg)*1.0e+3

	def getPeakCurrent(self):
		"""
		Returns peak current of the beam 
		"""
		return self.peak_current

	def getBPM_Time(self):
		"""
		Returns the arrival time of the synchronous particle.
		"""
		return self.bpm_time
		
	def getDeltaPhase(self):
		"""
		Returns the difference between phases of synch. particle and the center of mass 
		of the bunch
		"""
		return self.delta_phase
		
	def getPhase(self):
		"""
		Returns the average phase of the particles in the bunch.
		"""		
		return self.avg_phase
		
	def getSynchParticlePhase(self):
		"""
		Returns the phase of the synchronous particle in the bunch.
		"""		
		return self.synch_phase
		
	def getBunchLongSize(self):
		"""
		Returns long. RMS in deg for RF frequency
		"""
		return self.z_rms_deg
		
	def getAmp(self):
		"""
		Returns BPM amplitude (Fourier amp at BPM frequency)
		"""
		return self.bpm_amp

	def getCoordinates(self):
		"""
		returns coordinates of the particle
		"""
		return (self.x,self.xp,self.y,self.yp,self.avg_phase,self.eKin)

def addModelBPM(node,position, bpm_frequency = 805.0e+6):
	"""
	Adds BPM Model node to the node as a child. By default the BPM frequency is 805 MHZ.
	"""
	peak_current = 38. # mA
	n_particles = 1000
	bpm_model_node = ModelBPM(twiss_analysis, node, position, peak_current, bpm_frequency)
	bpm_model_node.setNumberParticles(n_particles)
	node.addChildNode(bpm_model_node,AccNode.ENTRANCE)
	return bpm_model_node	
