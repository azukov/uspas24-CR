#!/usr/bin/env python

#--------------------------------------------------------
# The classes that operates with PyORBIT Matrix class 
#--------------------------------------------------------

import math
import sys
import os
import random
import time

from orbit.core.orbit_utils import Matrix, PhaseVector
from orbit.core.bunch import Bunch

def printMatrix(m, st = "", frmt = "%12.5g"):
	"""
	Prints 2D PyORBIT matrix.
	"""
	print (st,"----matrix--- size=",m.size())
	for i in range(m.size()[0]):
		for j in range(m.size()[1]):
			print (("m(" + str(i) + "," + str(j)+")="+frmt%m.get(i,j) + " "), end =" ")
		print ("")	
		
def printVector(v, st = "", frmt = "%12.5g"):
	"""
	Prints 1D PyORBIT phase vector.
	"""	
	print (st,"---PhaseVector---- size=",v.size())
	for i in range(v.size()):
		print (("v(" + str(i) + ")="+frmt%v.get(i) + " "), end =" ")
	print ("")		
	
def makeMatrix(arr):
	"""
	Sets up and retruns PyORBIT matrix from Python 2D list
	"""
	n = len(arr)
	m = Matrix(n,n)
	for i in range(n):
		for j in range(n):
			m.set(i,j,arr[i][j])
	return m
	
def makePhaseVector(arr):
	"""
	Returns PyORBIT PhaseVector made from 1D list 
	"""
	n = len(arr)
	v = PhaseVector(n)
	for ind in range(v.size()):
		v.set(ind,arr[ind])
	return v

def getDriftMatrix2x2(length):
	"""
	Returns 2x2 drift element transport matrix
	for x,x' and y,y' coordinates
	"""
	matr = Matrix(2,2)
	matr.set(0,0,1.0)
	matr.set(0,1,length)
	matr.set(1,0,0.)
	matr.set(1,1,1.0)
	return matr	

def getLongitudinalDriftMatrix2x2(length,beta,mass):
	"""
	Returns 2x2 drift element transport matrix for a drift
	for longitudinal z,dE coordinates in (meters,GeV)
	beta - is relativistic parameter
	mass - is a mass in GeV
	"""
	gamma = 1.0/math.sqrt(1-beta**2)
	matr = Matrix(2,2)
	matr.set(0,0,1.0)
	matr.set(0,1,length/(gamma**3*beta**2*mass))
	matr.set(1,0,0.)
	matr.set(1,1,1.0)
	return matr
	
def getLongitudinalRfCavityMatrix2x2(qE0TL,rf_frequency,beta,rf_phase):
	"""
	Returns 2x2 drift element transport matrix for RF cavity
	for longitudinal z,dE coordinates in (meters,GeV)
	qE0TL - multiplication of charge, cavity voltage, and transit time factor
	rf_frequency - RF cavity frequency in Hz
	beta - is relativistic parameter
	rf_phase - in degrees, in formula dE = qE0TL*cos(rf_phase)
	"""
	v_light = 2.99792458e+8  # in [m/sec]
	matr_elem_1_0  = -qE0TL*(2*math.pi*rf_frequency)/(beta*v_light)
	matr_elem_1_0 *= math.sin(math.pi*rf_phase/180.)
	matr = Matrix(2,2)
	matr.set(0,0,1.0)
	matr.set(0,1,0.0)
	matr.set(1,0,matr_elem_1_0)
	matr.set(1,1,1.0)
	return matr
	
def getThinQuadMatrix2x2(momentum,gradient,length,charge = +1.0):
	"""
	Transport matrix for thin quad represented by drift-thin_quad-drift
	If G < 0. it is QH - horizontally focusing quad for charge = -1 (H- ions)
	momentum - in GeV/c
	gradient - in T/m
	length - in m	
	"""
	#---- multiplication of magnetic field B and bending radius of curvature Rho
	#---- B in Tesla, Rho in meters when momentum is in GeV/c
	b_rho = 3.33564*momentum
	matr_quad = Matrix(2,2)
	matr_quad.set(0,0,1.0)
	matr_quad.set(1,1,1.0)
	matr_quad.set(1,0,-charge*gradient*length/b_rho)
	matr_quad.set(0,1,0.0)
	q_drift1_mtr = getDriftMatrix2x2(length/2)
	q_drift2_mtr = getDriftMatrix2x2(length/2)
	matr_quad = q_drift2_mtr.mult(matr_quad.mult(q_drift1_mtr))	
	return matr_quad

def getQuadMatrix2x2(momentum,gradient,length,charge = +1.0):
	"""
	Transport matrix for quad.
	If G < 0.0 it is focusing quad for charge = -1 (H- ions)
	If G > 0.0 it is de-focusing quad for charge = -1 (H- ions)
	momentum - in GeV/c
	gradient - in T/m
	length - in m	
	"""
	#---- multiplication of magnetic field B and bending radius of curvature Rho
	#---- B in Tesla, Rho in meters when momentum is in GeV/c
	b_rho = 3.33564*momentum	
	G = gradient
	#---- length != 0. - thick quad transport matrix
	cappa2 = abs(G)/b_rho
	cappa = math.sqrt(cappa2)
	matr_quad = Matrix(2,2)
	if(gradient*charge > 0.):
		matr_quad.set(0,0,math.cos(cappa*length))
		matr_quad.set(0,1,math.sin(cappa*length)/cappa)
		matr_quad.set(1,0,-cappa*math.sin(cappa*length))
		matr_quad.set(1,1,math.cos(cappa*length))
	if(gradient*charge < 0.):
		matr_quad.set(0,0,math.cosh(cappa*length))
		matr_quad.set(0,1,math.sinh(cappa*length)/cappa)
		matr_quad.set(1,0,cappa*math.sinh(cappa*length))
		matr_quad.set(1,1,math.cosh(cappa*length))
	return matr_quad

def getQuadMatrix4x4(momentum,gradient,length,charge = +1.0):
	"""
	Returns transport PyORBIT 4x4 matrix for quad.
	momentum - in GeV/c
	gradient - in T/m
	length - in m
	"""
	kqc = charge*gradient/(3.335640952*momentum)	
	sqrt_kq = math.sqrt(abs(kqc))
	kqlength = sqrt_kq * length
	cn = math.cos(kqlength)
	sn = math.sin(kqlength)
	ch = math.cosh(kqlength)
	sh = math.sinh(kqlength)
	arr = [[],[],[],[]]
	if(kqc > 0.):
		arr[0] = [          cn, sn/sqrt_kq,          0.,         0.]
		arr[1] = [ -sn*sqrt_kq,         cn,          0.,         0.]
		arr[2] = [          0.,         0.,          ch, sh/sqrt_kq]
		arr[3] = [          0.,         0.,  sh*sqrt_kq,        ch ]
	else:
		arr[0] = [          ch, sh/sqrt_kq,          0.,         0.]
		arr[1] = [  sh*sqrt_kq,         ch,          0.,         0.]
		arr[2] = [          0.,         0.,          cn, sn/sqrt_kq]
		arr[3] = [          0.,         0., -sn*sqrt_kq,        cn ]
	return makeMatrix(arr)
	
def getDriftMatrix4x4(length):
	"""
	Returns transport PyORBIT 4x4 matrix for drift
	for x,x' and y,y' coordinates
	"""
	arr = [[],[],[],[]]
	arr[0] = [          1.,     length,          0.,         0.]
	arr[1] = [          0.,         1.,          0.,         0.]
	arr[2] = [          0.,         0.,          1.,     length]
	arr[3] = [          0.,         0.,          0.,        1. ]
	return makeMatrix(arr)

def getRotationMatrixZ4x4(angle):
	"""
	Returns rotation PyORBIT 4x4 matrix for Z-axis rotation
	for x,x' and y,y' coordinates
	"""
	cs = math.cos(angle)
	sn = math.sin(angle)
	arr = [[],[],[],[]]
	arr[0] = [  cs,  0., -sn,  0.]
	arr[1] = [  0.,  cs,  0., -sn]
	arr[2] = [  sn,  0.,  cs,  0.]
	arr[3] = [  0.,  sn,  0.,  cs]
	return makeMatrix(arr)

def trackBunchThrough4x4(bunch,matrix):
	"""
	Tracks bunch particles through the 4x4 PyORBIT matrix for x,xp,y,yp.
	Returns new bunch with new coordinates. 
	"""
	m = matrix
	bunch_out = Bunch()
	bunch.copyEmptyBunchTo(bunch_out)
	vct = PhaseVector(4)
	for ind in range(bunch.getSize()):
		vct.set(0,bunch.x(ind))
		vct.set(1,bunch.xp(ind))
		vct.set(2,bunch.y(ind))
		vct.set(3,bunch.yp(ind))
		#-----------------------------
		vout = matrix.mult(vct)
		#-----------------------------
		z = bunch.z(ind)
		dE = bunch.dE(ind)
		bunch_out.addParticle(vout.get(0),vout.get(1),vout.get(2),vout.get(3),z,dE)
	return bunch_out

def trackBunchThrough2x2(bunch,matrix,plane_index = 2):
	"""
	Tracks bunch particles through the 2x2 PyORBIT transport matrix for
	(x,xp), (y,yp), or (z,dE) planes, plane_index = 0,1,2 accordingly.
	Returns new bunch with new coordinates. 
	"""
	m = matrix
	bunch_out = Bunch()
	bunch.copyEmptyBunchTo(bunch_out)
	vct = PhaseVector(2)
	for ind in range(bunch.getSize()):
		if(plane_index == 0):
			vct.set(0,bunch.x(ind))
			vct.set(1,bunch.xp(ind))
		elif(plane_index == 1):	
			vct.set(0,bunch.y(ind))
			vct.set(1,bunch.yp(ind))
		elif(plane_index == 2):	
			vct.set(0,bunch.z(ind))
			vct.set(1,bunch.dE(ind))			
		#-----------------------------
		vout = matrix.mult(vct)
		#-----------------------------
		if(plane_index == 0):
			y = bunch.y(ind)
			yp =bunch.yp(ind) 
			z = bunch.z(ind)
			dE = bunch.dE(ind)
			bunch_out.addParticle(vout.get(0),vout.get(1),y,yp,z,dE)
		if(plane_index == 1):
			x = bunch.x(ind)
			xp =bunch.xp(ind) 
			z = bunch.z(ind)
			dE = bunch.dE(ind)
			bunch_out.addParticle(x,xp,vout.get(0),vout.get(1),z,dE)
		if(plane_index == 1):
			x = bunch.x(ind)
			xp =bunch.xp(ind) 
			y = bunch.y(ind)
			yp =bunch.yp(ind) 
			bunch_out.addParticle(x,xp,y,yp,vout.get(0),vout.get(1))		
	return bunch_out

def getCovarianceMatrix(lsq_matrix):
	"""
	Returns the Covariance matrix from
	the 1st lines of transport matrix.
	lsq matrix defines the set of equations
	<x^2> = m11^2*<x0^2) + 2*m11*m12*<x0*xp0> + m12^2*<xp0^2>
	...
	for different measurements.
	m11 and m12 are elements of the 1st line of 2x2 transport matrix. 
	"""
	#---- covMtrx = (M^T * M)^(-1)
	lsq_matrix_T = Matrix(lsq_matrix)
	lsq_matrix_T.transpose()
	covMtrx = (lsq_matrix_T.mult(lsq_matrix)).invert()
	return covMtrx
	
def getCovarianceMatrixWithWeights(lsq_matrix,w_matrix):
	"""
	Returns the variance-covariance matrix for lsq matrix 
	the weight matrix usually with 1/error^2 on the diagonal.
	The variance-covariance matrix can be called the error matrix
	for parameters.
	"""
	#---- covMtrx = (M^T * W * M)^(-1)
	lsq_matrix_T = Matrix(lsq_matrix)
	lsq_matrix_T.transpose()
	covMtrx = (lsq_matrix_T.mult(w_matrix.mult(lsq_matrix))).invert()
	return covMtrx
	
def getBeamCorrelations(rms2_vector,lsq_matrix):
	"""
	Returns PyORBIT PhaseVector with [<x*x>,<x*x'>,<x'*x'>] or [<y*y>,<y*y'>,<y'*y'>]
	as a solution of matrix equation by LSQ method
	"""
	#---- covMtrx = (M^T * M)^(-1) where M is LSQ_Matrix
	covMtrx = getCovarianceMatrix(lsq_matrix)
	#---- transposed lsq_matrix
	lsq_matrix_T = Matrix(lsq_matrix)
	lsq_matrix_T.transpose()
	#---- V(results) = (M^T * M)^-1 * M^T * V(rms2) where M is LSQ_Matrix
	corr_vector = covMtrx.mult(lsq_matrix_T.mult(rms2_vector))
	return corr_vector

def getBeamCorrelationsWithWeights(rms2_vector,lsq_matrix,w_matrix):
	"""
	Returns PyORBIT PhaseVector with [<x*x>,<x*x'>,<x'*x'>] or [<y*y>,<y*y'>,<y'*y'>]
	as a solution of matrix equation by LSQ method
	"""
	#---- covMtrx = (M^T * W * M)^(-1) where M is LSQ_Matrix
	covMtrx = getCovarianceMatrixWithWeights(lsq_matrix,w_matrix)
	#---- transposed lsq_matrix
	lsq_matrix_T = Matrix(lsq_matrix)
	lsq_matrix_T.transpose()
	#---- V(results) = (M^T * M)^-1 * M^T * W * V(rms2) where M is LSQ_Matrix
	corr_vector = covMtrx.mult(lsq_matrix_T.mult(w_matrix.mult(rms2_vector)))
	return corr_vector
	
def getErrorWeghtMatrix(rms2_vector,relative_error = 0.05):
	"""
	Returns the wheight error matrix wich has 1/sigma^2 on the diagonal
	for each WS RMS^2 for different quad gradients.
	Relative error is for RMS, for RMS2 the sigma2 will be 2*relative_error*RMS2
	"""
	w_matrix = Matrix(rms2_vector.size(),rms2_vector.size())
	w_matrix.zero()
	for ind in range(rms2_vector.size()):
		sigma2 = 2*relative_error*rms2_vector.get(ind)
		w_matrix.set(ind,ind,1./sigma2)
	return w_matrix
	