#!/usr/bin/env python

#--------------------------------------------------------
# The classes for BPM Model Accelerator Node
#--------------------------------------------------------

import math
import sys
import os
import random
import time

from orbit.py_linac.lattice import LinacPhaseApertureNode
from orbit.lattice import AccNode

def addPhaseApertureNodes(accLattice, max_periods_number = 2.0):
	#----------------------------------------------------------------------
	# These aperture nodes will remove particles from the bunch
	# if their phases are outside the -PI*N_Periods to +PI*N_Periods limits.
	# Each RF gap will has this aperture node.
	#----------------------------------------------------------------------
	node_pos_dict = accLattice.getNodePositionsDict()
	phaseAprtNodes = []
	for node in accLattice.getRF_Gaps():
		cav = node.getRF_Cavity()
		frequency = cav.getFrequency()
		phaseAperture = LinacPhaseApertureNode(frequency,node.getName()+":phaseAprt")
		pos = node_pos_dict[node][1]
		phaseAperture.setPosition(pos)
		phaseAperture.setMinMaxPhase(-180.*max_periods_number,+180.*max_periods_number)
		node.addChildNode(phaseAperture,AccNode.EXIT)
		phaseAprtNodes.append(phaseAperture)
	return phaseAprtNodes
