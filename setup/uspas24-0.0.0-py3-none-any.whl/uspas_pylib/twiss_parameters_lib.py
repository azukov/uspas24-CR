#!/usr/bin/env python

#--------------------------------------------------------
# The classes that related to Twiss parameters
#--------------------------------------------------------

import math

from orbit.core.orbit_utils import Matrix, PhaseVector


def emittanceFunc(param_val_vector):
	"""
	Calculates emittance from correlations:
	emitt = math.sqrt(<x*x> * <x'*x'> - (<x*x'>)^2)
	PhaseVector param_val_vector = (<x*x> , <x*x'> , <x'*x'>)
	"""
	vct = param_val_vector
	emitt = math.sqrt(vct.get(0)*vct.get(2) - (vct.get(1))**2)
	return emitt

def alphaFunc(param_val_vector):
	"""
	Calculates Twiss alpha from correlations:
	alpha = -<x*x'>/emittance 
	PhaseVector param_val_vector = (<x*x> , <x*x'> , <x'*x'>)
	"""
	vct = param_val_vector
	alpha = -vct.get(1)/math.sqrt(vct.get(0)*vct.get(2) - (vct.get(1))**2)
	return alpha
	
def betaFunc(param_val_vector):
	"""
	Calculates Twiss alpha from correlations:
	alpha = -<x*x'>/emittance 
	PhaseVector param_val_vector = (<x*x> , <x*x'> , <x'*x'>)
	"""
	vct = param_val_vector
	beta = vct.get(0)/math.sqrt(vct.get(0)*vct.get(2) - (vct.get(1))**2)
	return beta