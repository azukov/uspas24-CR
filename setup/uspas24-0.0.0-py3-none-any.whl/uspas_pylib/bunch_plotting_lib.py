#!/usr/bin/env python

#--------------------------------------------------------
# The classes to plot Bunch related distribution
#--------------------------------------------------------

import math
import sys
import os
import random
import time

import matplotlib.pyplot as plt

def plotBunch2D(bunch,dir_indexX=0,dir_indexY=2,title="Bunch 2D"):
	"""
	Plots the points on 2D plot for particular coordinates of macro-particles
	in the bunch (x,xp) or (x,y) etc.
	By default it will plot (x,y) points.
	"""
	arrX = []
	arrY = []
	for ind in range(bunch.getSize()):
		arrCoords = (bunch.x(ind)*1000.,bunch.xp(ind)*1000.,bunch.y(ind)*1000.,bunch.xp(ind)*1000.,bunch.z(ind),bunch.dE(ind))
		arrX.append(arrCoords[dir_indexX])
		arrY.append(arrCoords[dir_indexY])
	plt.title(title)
	lines = plt.plot(arrX,arrY, 'bo')
	plt.setp(lines,"ms",1)
	plt.show()
	
def plotBunchXY_2D(bunch,title="Bunch 2D"):
	"""	
	Plots the points on 2D graph X and Y coordinates of macro-particles
	in the bunch.
	"""
	dir_indexX=0
	dir_indexY=2
	plotBunch2D(bunch,dir_indexX,dir_indexY,title)

